---
date: '2025-07-18'
layout: sessions-index
seminars:
- 202506 AICon Beijing
title: 研討會總覽
total_sessions: 30
type: sessions-overview
weight: 3
---

# 研討會總覽

本系統共收錄了 **30** 場會議，涵蓋 **1** 個研討會。

## 研討會列表

### 202506 AICon Beijing

共 30 場會議

- [AI Agent 如何重塑有声内容的生产与分发](../sessions/766c6ee4-f776-4147-93c9-1257c7d9ac16_ai-agent-如何重塑有声内容的生产与分发.md)
- [AI Agent+IoT技术方案新场景创新应用](../sessions/8ab99e20-b987-4746-9b99-fd87b472994b_ai-agentiot技术方案新场景创新应用.md)
- [AI赋能eBay支付风控：从用户行为到交易安全的全面智能化](../sessions/f48d2c98-796a-4718-9c29-a581be823a14_ai赋能ebay支付风控从用户行为到交易安全的全面智能化.md)
- [CangjieMagic：基于仓颉语言的Agent开发框架实践](../sessions/111579d4-80c4-4348-a24f-51c6d6a8559f_cangjiemagic基于仓颉语言的agent开发框架实践.md)
- [Coding Agent 驱动研发提效：从实践到流程改进](../sessions/12d77a9f-8044-4808-8f3e-36f0323abd20_coding-agent-驱动研发提效从实践到流程改进.md)
- [DLRover在万卡规模大模型训练中的稳定性实践](../sessions/6db34cc7-59de-4947-abb6-5437e8fe205c_dlrover在万卡规模大模型训练中的稳定性实践.md)
- [Data+AI 下一代数智平台建设](../sessions/688e55cf-8ef8-4b06-8343-8ada032d3b50_dataai-下一代数智平台建设.md)
- [DeepResearch如何在企业内落地](../sessions/25c654c8-e060-467d-8668-8e908b211888_deepresearch如何在企业内落地.md)
- [GenAI 应用时代，开发思想如何变革？](../sessions/f58850fb-aae3-4aaf-9a8f-0bc758b933e7_genai-应用时代开发思想如何变革.md)
- [Infinity：视觉自回归生成新路线](../sessions/e53a6872-069f-49fc-821a-43f324666ec0_infinity视觉自回归生成新路线.md)
- ... 還有 20 場會議

